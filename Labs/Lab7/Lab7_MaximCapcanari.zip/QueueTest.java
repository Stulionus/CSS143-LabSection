package Labs.Lab7;

import java.util.LinkedList;
import java.util.Queue;

public class QueueTest {
    public static void main(String[] args) {
        Queue q = new LinkedList();
        q.add('R');
        q.add('a');
        q.add('c');
        q.add('e');
        //a.push('c');
        //a.push('a');
        q.add('r');
        System.out.println("Size : " + q.size());
        while(!q.isEmpty()) {
            System.out.println(q.remove());
        }
    }
}
