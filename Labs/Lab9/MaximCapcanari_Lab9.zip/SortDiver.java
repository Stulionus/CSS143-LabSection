package Labs.Lab9;

/**
 * This class is provided mainly as the driver for you to test your implemented methods
 * Uncomment and run the corresponding code as you progress.
 * 
 * @author (your name) 
 * @version (CSSSKL 143)
 */
public class SortDiver {
 public static void main(String[] args) {
        
        MyArrayList array = new MyArrayList();
        MyArrayList other = new MyArrayList();
        
        System.out.print("Object instance lists: \n");
        for(int i = 0; i < array.IntList.length; i++) {
            System.out.print(array.IntList[i] + "|");
        } 
        System.out.println();
        
          for(int i = 0; i < array.CharList.length; i++) {
           System.out.print(array.CharList[i] + "|");
        }
        System.out.println();
        
        for(int i = 0; i < array.StringList.length; i++) {
            System.out.print(array.StringList[i] + "|");
        }
        System.out.println();
        
        // testing bubble sort for ints
        array.intBubbleSort();
        System.out.print("\n\nSorted int array: \n" );
        for(int i = 0; i < array.IntList.length; i++) {
           System.out.print(array.IntList[i] + "|");
        }  
        // testing bubble sort for chars
        array.CharBubbleSort();
        System.out.print("\n\nSorted char array: \n" );
        for(int i = 0; i < array.CharList.length; i++) {
           System.out.print(array.CharList[i] + "|");
        }  
        
        // testing bubble sort for strings
        /*
        array.stringBubbleSort();
        System.out.print("\n\nSorted String array: \n" );
        for(int i = 0; i < array.StringList.length; i++) {
           System.out.print(array.StringList[i] + "|");
        } 

        // NOTE: You must comment out previous calls for int sort methods, 
        //       at this point the arrays are already sorted!
        array.selectionSort();
        System.out.print("\n\nSorted int array using selectionSort(): \n" );
        for(int i = 0; i < array.IntList.length; i++) {
           System.out.print(array.IntList[i] + "|");
        } 
        */
        // NOTE: You must comment out previous calls for String sort methods, 
        //       at this point the arrays are already sorted!
        array.stringSelectionSort();
        System.out.print("\n\nSorted String array using stringSelectionSort(): \n" );
        for(int i = 0; i < array.StringList.length; i++) {
           System.out.print(array.StringList[i] + "|");
        }
        System.out.println();
        // lets see what is in other object first
        System.out.println("\nOther object's IntList[] has: " );
        for(int i = 0; i < other.IntList.length; i++) {
            System.out.print(other.IntList[i] + "|");
        } 
        System.out.println();
        
        array.compareTo(other);    
       
    }
   } 

    

